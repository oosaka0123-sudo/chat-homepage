const dayNames = ['今日', '明日', '明後日'];
const dateInJapan = new Intl.DateTimeFormat('sv-SE', {timeZone: 'Asia/Tokyo'});
const updatedInJapan = new Intl.DateTimeFormat('ja-JP', {
  timeZone: 'Asia/Tokyo', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit'
});
const directions = ['北','北北東','北東','東北東','東','東南東','南東','南南東','南','南南西','南西','西南西','西','西北西','北西','北北西'];
const weatherLabels = new Map([
  [0,'快晴'],[1,'晴れ'],[2,'晴れ時々曇り'],[3,'曇り'],[45,'霧'],[48,'着氷性の霧'],
  ...[51,53,55].map(code=>[code,'霧雨']), ...[56,57].map(code=>[code,'着氷性の霧雨']),
  ...[61,63,65].map(code=>[code,'雨']), ...[66,67].map(code=>[code,'着氷性の雨']),
  ...[71,73,75,77].map(code=>[code,'雪']), ...[80,81,82].map(code=>[code,'にわか雨']),
  ...[85,86].map(code=>[code,'にわか雪']), ...[95,96,99].map(code=>[code,'雷雨'])
]);

function display(field, value) {
  if (!Number.isFinite(value)) return '—';
  if (field.startsWith('wind_direction')) return directions[Math.round(value / 22.5) % 16];
  if (field === 'weather_code') return weatherLabels.get(value) ?? '—';
  return value.toFixed(1);
}

function initTabs(group, changeDay) {
  const buttons = group.querySelectorAll('[data-day]');
  for (const button of buttons) {
    button.addEventListener('click', () => {
      for (const tab of buttons) {
        tab.classList.toggle('is-active', tab === button);
        tab.setAttribute('aria-pressed', String(tab === button));
      }
      changeDay(Number(button.dataset.day));
    });
  }
}

function waveWindChart(data, day) {
  if (!data || !Number.isInteger(day) || day < 0 || day > 2) return '';
  const read = (feed, field, index) => {
    const value = feed?.hourly?.[field]?.[index];
    return Number.isFinite(value) && value >= 0 ? value : null;
  };
  const series = (feed, field) => Array.from({length: 8}, (_, i) => read(feed, field, day * 24 + i * 3));
  const wave = series(data.marine, 'wave_height');
  const wind = series(data.weather, 'wind_speed_10m');
  if ([...wave, ...wind].every(v => v === null)) return '';
  const maximum = (feed, field, interval) => {
    const values = Array.from({length: 72}, (_, i) => read(feed, field, i)).filter(v => v !== null);
    return Math.max(interval * 4, Math.ceil(Math.max(0, ...values) / (interval * 4)) * interval * 4);
  };
  const waveMax = maximum(data.marine, 'wave_height', 0.5);
  const windMax = maximum(data.weather, 'wind_speed_10m', 2.5);
  const x = i => 76 + i * 80;
  const y = (value, max) => 190 - value / max * 160;
  let svg = '<svg class="forecast-chart" viewBox="0 0 720 230" role="img" aria-label="沖合波高と風速の3時間ごとの予報。数値は下の表にも掲載しています。" xmlns="http://www.w3.org/2000/svg">';
  for (let i = 0; i <= 4; i++) {
    const yy = 190 - i * 40;
    svg += '<line x1="48" y1="' + yy + '" x2="666" y2="' + yy + '" class="kyushu-chart-grid"/>';
    svg += '<text x="43" y="' + (yy + 4) + '" text-anchor="end" class="kyushu-wave-axis">' + (waveMax * i / 4).toFixed(1) + '</text>';
    svg += '<text x="671" y="' + (yy + 4) + '" class="kyushu-wind-axis">' + (windMax * i / 4).toFixed(1) + '</text>';
  }
  wave.forEach((value, i) => {
    if (value !== null) svg += '<rect class="kyushu-wave-bar" x="' + (x(i) - 18) + '" y="' + y(value, waveMax) + '" width="36" height="' + (190 - y(value, waveMax)) + '" rx="2"/>';
  });
  wind.forEach((value, i) => {
    if (value === null) return;
    const yy = y(value, windMax);
    if (i > 0 && wind[i - 1] !== null) svg += '<line class="kyushu-wind-line" x1="' + x(i - 1) + '" y1="' + y(wind[i - 1], windMax) + '" x2="' + x(i) + '" y2="' + yy + '"/>';
    svg += '<circle class="kyushu-wind-point" cx="' + x(i) + '" cy="' + yy + '" r="4"/>';
  });
  for (let i = 0; i < 8; i++) svg += '<text x="' + x(i) + '" y="214" text-anchor="middle" class="kyushu-time-axis">' + String(i * 3).padStart(2, '0') + ':00</text>';
  return svg + '</svg>';
}

function initForecast(group) {
  const status = group.querySelector('[data-status]');
  const chart = group.querySelector('[data-wave-chart]');
  const dailyRows = document.querySelectorAll('#daily tbody tr');
  const hourlyCells = group.querySelectorAll('[data-field]');
  let forecast;
  let selected = 0;
  let waiting = true;

  function render() {
    const now = Date.now();
    const age = now - Date.parse(forecast?.retrieved);
    const valid = age >= 0 && age < 6 * 3600000 &&
      forecast?.marine?.daily?.time?.[0] === dateInJapan.format(now);
    const data = valid ? forecast : null;
    if (chart) chart.innerHTML = waveWindChart(data, selected) || '<p class="chart-empty">最新の波・風予報は未取得です。</p>';
    if (data) {
      const grid = data.marine;
      status.textContent = dayNames[selected] + ' ' + grid.daily.time[selected] +
        '（日本時間）｜沖合格子 ' + grid.latitude.toFixed(3) + '°N, ' + grid.longitude.toFixed(3) +
        '°E｜取得 ' + updatedInJapan.format(Date.parse(data.retrieved));
    } else {
      status.textContent = waiting ? '予報を読み込んでいます。' : '最新の予報は未取得です。';
    }
    for (const cell of hourlyCells) {
      const {field, hour} = cell.dataset;
      if (field === 'time') continue;
      const feed = field.startsWith('wave_') ? data?.marine : data?.weather;
      cell.textContent = display(field, feed?.hourly[field]?.[24 * selected + Number(hour)]);
    }
    const columns = ['weather_code','wave_height_max','wind_speed_10m_max','wind_direction_10m_dominant'];
    dailyRows.forEach((row, index) => {
      row.cells[0].textContent = data?.marine.daily.time[index]?.slice(5).replace('-', '/') ?? (index + 1) + '日目';
      columns.forEach((field, column) => {
        const feed = field === 'wave_height_max' ? data?.marine : data?.weather;
        row.cells[column + 1].textContent = display(field, feed?.daily[field]?.[index]);
      });
    });
  }

  async function refresh() {
    try {
      const response = await fetch('../../data/' + group.dataset.spot + '.json', {cache: 'no-cache'});
      if (!response.ok) throw new Error('Forecast unavailable');
      const result = await response.json();
      if (result.id === group.dataset.spot) forecast = result;
    } catch {
      // An open page can keep the last successfully retrieved forecast until it expires.
    } finally {
      waiting = false;
      render();
    }
  }

  initTabs(group, day => { selected = day; render(); });
  render();
  refresh();
  setInterval(refresh, 5 * 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { render(); refresh(); } });
}

const ranking = document.querySelector('[data-tabs="ranking"]');
if (ranking) initTabs(ranking, day => {
  ranking.querySelector('[data-day-text]').textContent = dayNames[day] + 'のランキングは保留中です。';
});
const forecastGroup = document.querySelector('[data-tabs="forecast"]');
if (forecastGroup) initForecast(forecastGroup);

function initWindy(group) {
  const frame = group.querySelector('iframe');
  const buttons = Array.from(group.querySelectorAll('button[data-overlay]'));
  for (const button of buttons) button.addEventListener('click', () => {
    const overlay = button.dataset.overlay;
    if (overlay !== 'wind' && overlay !== 'waves') return;
    const next = group.dataset[overlay === 'wind' ? 'windUrl' : 'wavesUrl'];
    if (!frame || !next || !next.startsWith('https://embed.windy.com/embed2.html?')) return;
    if (frame.getAttribute('src') !== next) frame.setAttribute('src', next);
    for (const item of buttons) {
      item.classList.toggle('is-active', item === button);
      item.setAttribute('aria-pressed', String(item === button));
    }
  });
}
const windyGroup = document.querySelector('[data-windy]');
if (windyGroup) initWindy(windyGroup);
