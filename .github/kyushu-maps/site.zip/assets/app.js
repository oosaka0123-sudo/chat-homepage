const dayNames = ['今日', '明日', '明後日'];
const dateInJapan = new Intl.DateTimeFormat('sv-SE', {timeZone: 'Asia/Tokyo'});
const updatedInJapan = new Intl.DateTimeFormat('ja-JP', {
  timeZone: 'Asia/Tokyo', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit'
});
const directions = ['北','北北東','北東','東北東','東','東南東','南東','南南東','南','南南西','南西','西南西','西','西北西','北西','北北西'];
const weatherLabels = new Map([
  [0,'快晴'],[1,'晴れ'],[2,'晴れ時々曇り'],[3,'曇り'],[45,'霧'],[48,'着氷性の霧'],
  ...[51,53,55].map(code=>[code,'霧雨']), ...[56,57].map(code=>[code,'着氷性の霧雨']),
  ...[61,63,65].map(code=>[code,'雨']), ...[66,67].map(code=>[code,'着氷性の雨']),
  ...[71,73,75,77].map(code=>[code,'雪']), ...[80,81,82].map(code=>[code,'にわか雨']),
  ...[85,86].map(code=>[code,'にわか雪']), ...[95,96,99].map(code=>[code,'雷雨'])
]);

function display(field, value) {
  if (!Number.isFinite(value)) return '—';
  if (field.startsWith('wind_direction')) return directions[Math.round(value / 22.5) % 16];
  if (field === 'weather_code') return weatherLabels.get(value) ?? '—';
  return value.toFixed(1);
}

function initTabs(group, changeDay) {
  const buttons = group.querySelectorAll('[data-day]');
  for (const button of buttons) {
    button.addEventListener('click', () => {
      for (const tab of buttons) {
        tab.classList.toggle('is-active', tab === button);
        tab.setAttribute('aria-pressed', String(tab === button));
      }
      changeDay(Number(button.dataset.day));
    });
  }
}

const hours=Array.from({length:17},(_,i)=>i+4);
const iconFor=code=>!Number.isFinite(code)?'—':code<=1?'☀️':code===2?'🌤️':code===3?'☁️':code<=48?'🌫️':code<=57?'🌦️':code<=67?'🌧️':code<=77?'🌨️':code<=82?'🌧️':code<=86?'🌨️':'⛈️';
const safeNumber=v=>Number.isFinite(v)&&v>=0?v:null;
function tideDay(data,day){const t=data?.reference_tide;const date=data?.marine?.daily?.time?.[day];return t?.status==='candidate_reference_only'&&t.local_applicability_verified===false&&Array.isArray(t.days)?t.days.find(d=>d.date===date):undefined;}
function tideCycleForDate(date){try{if(!date)return '—';const n=Number(new Intl.DateTimeFormat('en-US-u-ca-chinese',{timeZone:'Asia/Tokyo',day:'numeric'}).formatToParts(new Date(date+'T12:00:00+09:00')).find(p=>p.type==='day')?.value);if(!Number.isInteger(n)||n<1||n>30)return '—';if([29,30,1,2,14,15,16,17].includes(n))return '大潮';if([7,8,9,22,23,24].includes(n))return '小潮';if([10,25].includes(n))return '長潮';if([11,26].includes(n))return '若潮';return '中潮';}catch{return '—';}}
function hourlyIcon(code,h){return (code===0||code===1)&&(h<6||h>=18)?'🌙':iconFor(code);}
function chartMarkup(data,day,rain=false,chosen=-1){
  if(!data||!Number.isInteger(day)||day<0||day>2)return '';
  const values=(feed,field)=>hours.map(h=>safeNumber(data[feed]?.hourly?.[field]?.[day*24+h]));
  const wave=values(rain?'weather':'marine',rain?'precipitation':'wave_height');
  const tide=rain?tideDay(data,day):null;
  const wind=rain?hours.map(h=>Number.isFinite(tide?.hourly_cm?.[h])?tide.hourly_cm[h]:null):values('weather','wind_speed_10m');
  if([...wave,...wind].every(v=>v===null))return '';
  const max=(feed,field,step)=>Math.max(step*4,Math.ceil(Math.max(0,...(data[feed]?.hourly?.[field]??[]).slice(0,72).filter(v=>safeNumber(v)!==null))/(step*4))*step*4);
  const waveMax=max(rain?'weather':'marine',rain?'precipitation':'wave_height',rain?1:0.5);
  const allTides=rain?[...(tide?.hourly_cm??[]),...(tide?.high??[]).map(e=>e.height_cm),...(tide?.low??[]).map(e=>e.height_cm)].filter(Number.isFinite):[];
  const tideMin=rain?Math.floor((Math.min(0,...allTides)-8)/20)*20:0;
  const windMax=rain?Math.max(tideMin+80,Math.ceil((Math.max(0,...allTides)+8)/20)*20):max('weather','wind_speed_10m',2.5);
  const height=rain?200:190, top=42,bottom=rain?182:184,usable=bottom-top;
  const x=i=>48+(i+.5)*40,y=(v,m)=>bottom-v/m*usable;
  const windY=v=>rain?bottom-(v-tideMin)/(windMax-tideMin)*usable:y(v,windMax);
  let svg='<svg class="forecast-chart" viewBox="0 0 728 '+height+'" preserveAspectRatio="none" role="img" aria-label="'+(rain?'参考港の天文潮位と降水量。現地実測ではありません。':'沖合波高と風速の時間別予報')+'" xmlns="http://www.w3.org/2000/svg">';
  if(chosen>=4&&chosen<=20)svg+='<rect x="'+(48+(chosen-4)*40)+'" y="0" width="40" height="'+height+'" class="ks-chart-selected"/>';
  for(let i=0;i<=4;i++){
    const yy=bottom-i*usable/4;
    svg+='<line x1="48" y1="'+yy+'" x2="728" y2="'+yy+'" class="kyushu-chart-grid"/>';
    svg+='<text x="2" y="'+(yy+3)+'" class="'+(rain?'ks-rain-axis':'kyushu-wave-axis')+'">'+(waveMax*i/4).toFixed(1)+'</text>';
    if(!rain||allTides.length)svg+='<text x="46" y="'+(yy+3)+'" text-anchor="end" class="'+(rain?'ks-tide-axis':'kyushu-wind-axis')+'">'+(rain?(tideMin+(windMax-tideMin)*i/4).toFixed(0):(windMax*i/4).toFixed(1))+'</text>';
  }
  const nowHour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(Date.now()));
  hours.forEach((h,i)=>{
    svg+='<line x1="'+x(i)+'" x2="'+x(i)+'" y1="'+top+'" y2="'+bottom+'" class="ks-vertical-grid"/>';
    if(!rain)svg+='<text x="'+x(i)+'" y="24" text-anchor="middle" class="ks-chart-weather">'+hourlyIcon(data.weather?.hourly?.weather_code?.[24*day+h],h)+'</text>';
  });
  wave.forEach((v,i)=>{if(v!==null)svg+='<rect class="'+(rain?'ks-rain-bar':'kyushu-wave-bar')+'" x="'+(x(i)-14)+'" y="'+y(v,waveMax)+'" width="28" height="'+(bottom-y(v,waveMax))+'" rx="2" opacity="'+(day===0&&hours[i]<nowHour?'.46':'.92')+'"/>';});
  wind.forEach((v,i)=>{if(v===null)return;const yy=windY(v);if(i&&wind[i-1]!==null)svg+='<line class="'+(rain?'ks-tide-line':'kyushu-wind-line')+'" x1="'+x(i-1)+'" y1="'+windY(wind[i-1])+'" x2="'+x(i)+'" y2="'+yy+'"/>';svg+='<circle class="'+(rain?'ks-tide-point':'kyushu-wind-point')+'" cx="'+x(i)+'" cy="'+yy+'" r="3"/>';});
  if(rain&&tide)for(const [label,events] of [['満潮',tide.high],['干潮',tide.low]])for(const e of events??[]){
    if(!/^\d{2}:\d{2}$/.test(e.time)||!Number.isFinite(e.height_cm))continue;
    const h=Number(e.time.slice(0,2))+Number(e.time.slice(3))/60;if(h<4||h>20)continue;
    const xx=x(h-4),yy=windY(e.height_cm),ty=yy<76?yy+15:yy-18;
    svg+='<circle class="ks-tide-event" cx="'+xx+'" cy="'+yy+'" r="3.8"/><text class="ks-tide-event-label" x="'+xx+'" y="'+ty+'" text-anchor="middle">'+label+'</text><text class="ks-tide-event-label" x="'+xx+'" y="'+(ty+11)+'" text-anchor="middle">'+e.time+'</text>';
  }
  return svg+'</svg>';
}
function waveWindChart(data,day,chosen=-1){return chartMarkup(data,day,false,chosen);}
function track(value,max,label,kind){return value===null?'<div class="daily-track">—</div>':'<div class="daily-track"><span class="daily-fill daily-'+kind+'" style="--daily-fill:'+Math.min(100,Math.max(0,100*value/(max||1))).toFixed(1)+'%"></span><span class="daily-val">'+label+'</span></div>';}
function renderDailyRows(rows,data){
  const daily=data?.daytime_daily??[];
  const maxWave=Math.max(0,...daily.map(d=>safeNumber(d.wave_max)??0)),maxWind=Math.max(0,...daily.map(d=>safeNumber(d.wind_mean)??0));
  rows.forEach((row,i)=>{
    const d=daily[i],cells=row.cells,date=d?.date;
    row.classList.toggle('is-today',i===0&&!!d);
    cells[0].textContent=/^\d{4}-\d{2}-\d{2}$/.test(date??'')?date.slice(5).replace('-','/')+' ('+['日','月','火','水','木','金','土'][new Date(date+'T12:00:00+09:00').getUTCDay()]+')':(i+1)+'日目';
    cells[1].textContent=iconFor(d?.weather_code);
    cells[1].title=weatherLabels.get(d?.weather_code)??'データなし';
    const lo=safeNumber(d?.wave_min),hi=safeNumber(d?.wave_max),w=safeNumber(d?.wind_mean);
    cells[2].innerHTML=track(lo===null?null:hi,maxWave,lo===null||hi===null?'—':lo.toFixed(1)+'-'+hi.toFixed(1)+'m','wave');
    cells[3].innerHTML=track(w,maxWind,w===null?'—':w.toFixed(1)+'m/s','wind');
    const dir=Number.isFinite(d?.wind_dir)?Math.round(d.wind_dir/45)%8:-1;
    cells[4].textContent=dir>=0?['↑','↗','→','↘','↓','↙','←','↖'][dir]+['北','北東','東','南東','南','南西','西','北西'][dir]:'—';
    cells[5].textContent='検証中';
  });
}
function initForecast(group) {
  const status = group.querySelector('[data-status]');
  const chart = group.querySelector('[data-wave-chart]');
  const rain = group.querySelector('[data-rain-chart]');
  const tideMeta = group.querySelector('[data-tide-meta]');
  const tidePhase=group.querySelector('[data-tide-phase]');
  const rainTotal=group.querySelector('[data-rain-total]');
  const dailyUpdated = document.querySelector('[data-daily-updated]');
  const dailyRows = document.querySelectorAll('#daily tbody tr');
  const hourlyCells = group.querySelectorAll('[data-field]');
  let forecast;
  let selected = 0;
  let chosenHour = Math.max(4,Math.min(20,Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(Date.now()))));
  let waiting = true;

  function render() {
    const now = Date.now();
    const age = now - Date.parse(forecast?.retrieved);
    const valid = age >= 0 && age < 6 * 3600000 &&
      forecast?.marine?.daily?.time?.[0] === dateInJapan.format(now);
    const data = valid ? forecast : null;
    if (chart) chart.innerHTML = waveWindChart(data, selected,chosenHour) || '<p class="chart-empty">最新の波・風予報は未取得です。</p>';
    const t=tideDay(data,selected);
    if(tideMeta){
      const name=data?.reference_tide?.name;
      const events=list=>Array.isArray(list)&&list.length?list.map(e=>e.time+' '+e.height_cm+'cm').join('・'):'—';
      tideMeta.textContent=(name?'参考港：'+name+'（地点適合未検証）':'参考港の潮位未取得')+'　満潮：'+events(t?.high)+'　干潮：'+events(t?.low);
    }
    if(tidePhase)tidePhase.textContent='潮回り：'+tideCycleForDate(data?.marine?.daily?.time?.[selected])+'（目安）';
    if(rainTotal){const vals=hours.map(h=>safeNumber(data?.weather?.hourly?.precipitation?.[selected*24+h])).filter(v=>v!==null);rainTotal.textContent=vals.length===17?'表示範囲合計 '+vals.reduce((a,b)=>a+b,0).toFixed(1)+'mm':vals.length?'取得済み分 '+vals.reduce((a,b)=>a+b,0).toFixed(1)+'mm（'+vals.length+'/17）':'降水データ未取得';}
    if(rain) rain.innerHTML=chartMarkup(data,selected,true,chosenHour)||'<p class="chart-empty">降水量データ未取得</p>';
    if (data) {
      const grid = data.marine;
      status.textContent = dayNames[selected] + ' ' + grid.daily.time[selected] +
        '（日本時間）｜沖合格子 ' + grid.latitude.toFixed(3) + '°N, ' + grid.longitude.toFixed(3) +
        '°E｜取得 ' + updatedInJapan.format(Date.parse(data.retrieved));
    } else {
      status.textContent = waiting ? '予報を読み込んでいます。' : '最新の予報は未取得です。';
    }
    for (const cell of hourlyCells) {
      const {field, hour} = cell.dataset;
      const idx=24*selected+Number(hour);
      cell.classList.toggle('current',Number(hour)===chosenHour);
      if(field==='time'){
        cell.textContent=String(hour).padStart(2,'0')+':00';
        if(cell.closest('.ks-tide-panel')){
          const weather=document.createElement('span');weather.className='weather-icon';
          const code=data?.weather?.hourly?.weather_code?.[idx];weather.textContent=hourlyIcon(code,Number(hour));weather.title=weatherLabels.get(code)??'天気未取得';cell.append(weather);
        }
        continue;
      }
      const feed = field.startsWith('wave_') ? data?.marine : data?.weather;
      const val=field==='tide'?t?.hourly_cm?.[Number(hour)]:feed?.hourly?.[field]?.[idx];
      cell.textContent = field==='tide'&&Number.isFinite(val)?String(val):field==='precipitation_probability'&&Number.isFinite(val)?String(Math.round(val)):display(field,val);
      if(field==='wind_direction_10m'&&Number.isFinite(val)&&val>=0&&val<=360){
        const dir=display(field,val);cell.textContent='';
        const arrow=document.createElement('span');arrow.className='ks-wind-arrow';arrow.textContent='↑';arrow.style.transform='rotate('+(val-180)+'deg)';arrow.setAttribute('aria-hidden','true');
        const label=document.createElement('small');label.className='ks-wind-direction';label.textContent=dir;cell.append(arrow,label);
      }
    }
    renderDailyRows(dailyRows,data);
    if(dailyUpdated)dailyUpdated.textContent=data?'更新：'+updatedInJapan.format(Date.parse(data.retrieved))+' JST':'予報データ未取得';

  }

  async function refresh() {
    try {
      const response = await fetch('../../data/' + group.dataset.spot + '.json', {cache: 'no-cache'});
      if (!response.ok) throw new Error('Forecast unavailable');
      const result = await response.json();
      if (result.id === group.dataset.spot) forecast = result;
    } catch {
      // An open page can keep the last successfully retrieved forecast until it expires.
    } finally {
      waiting = false;
      render();
    }
  }

  const scrollers=[...group.querySelectorAll('[data-sync-scroll]')];
  for(const scroller of scrollers)scroller.addEventListener('scroll',()=>{for(const other of scrollers)if(other!==scroller&&Math.abs(other.scrollLeft-scroller.scrollLeft)>1)other.scrollLeft=scroller.scrollLeft;});
  for(const cell of hourlyCells)cell.addEventListener('click',()=>{chosenHour=Number(cell.dataset.hour);render();});
  initTabs(group, day => { selected = day; chosenHour=day===0?Math.max(4,Math.min(20,Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Tokyo',hour:'2-digit',hourCycle:'h23'}).format(Date.now())))):4; render(); for(const scroller of scrollers)scroller.scrollLeft=Math.max(0,(chosenHour-6)*40); });
  render();
  refresh();
  for(const scroller of scrollers)scroller.scrollLeft=Math.max(0,(chosenHour-6)*40);
  setInterval(refresh, 5 * 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { render(); refresh(); } });
}

const ranking = document.querySelector('[data-tabs="ranking"]');
if (ranking) initTabs(ranking, day => {
  ranking.querySelector('[data-day-text]').textContent = dayNames[day] + 'のランキングは保留中です。';
});
const forecastGroup = document.querySelector('[data-tabs="forecast"]');
if (forecastGroup) initForecast(forecastGroup);

function initWindy(group) {
  const frame = group.querySelector('iframe');
  const buttons = Array.from(group.querySelectorAll('button[data-overlay]'));
  for (const button of buttons) button.addEventListener('click', () => {
    const overlay = button.dataset.overlay;
    if (overlay !== 'wind' && overlay !== 'waves') return;
    const next = group.dataset[overlay === 'wind' ? 'windUrl' : 'wavesUrl'];
    if (!frame || !next || !next.startsWith('https://embed.windy.com/embed2.html?')) return;
    if (frame.getAttribute('src') !== next) frame.setAttribute('src', next);
    for (const item of buttons) {
      item.classList.toggle('is-active', item === button);
      item.setAttribute('aria-pressed', String(item === button));
    }
  });
}
const windyGroup = document.querySelector('[data-windy]');
if (windyGroup) initWindy(windyGroup);
